export enum IntegrationType {
  SHOPIFY = 'SHOPIFY',
  GMAIL = 'GMAIL',
  MAIL_GUN = 'MAIL_GUN',
  SEND_GRID = 'SEND_GRID',
}
