import { Injectable } from '@nestjs/common';
import { IntegrationService } from './integration.service';
import { IntegrationType } from './types';
import { ShopifyIntegrationService } from './services/shopify.helper.service';
import { GmailIntegrationService } from './services/gmail.helper.service';
import { MailgunIntegrationService } from './services/mailgun.helper.service';
import { SendGridIntegrationService } from './services/sendgrid.helper.service';
import { validateIntegrationData } from './validationSchemas';

export const INTEGRATION_SINGULARITY = {
  GMAIL: false, // Gmail integrations are not singular (multiple per organization)
  SHOPIFY: true, // Shopify integration is singular (one per organization)
};

@Injectable()
export class IntegrationManager {
  private integrationServices: Map<IntegrationType, IntegrationService<object>>;


  constructor() {
    this.integrationServices = new Map<
      IntegrationType,
      IntegrationService<object>
    >();
    this.integrationServices.set(
      IntegrationType.SHOPIFY,
      new ShopifyIntegrationService(),
    );
    this.integrationServices.set(
      IntegrationType.GMAIL,
      new GmailIntegrationService(),
    );
    this.integrationServices.set(
      IntegrationType.MAIL_GUN,
      new MailgunIntegrationService(),
    );
    this.integrationServices.set(
      IntegrationType.SEND_GRID,
      new SendGridIntegrationService(),
    );
  }

  public async createIntegration(type: IntegrationType, config: any) {
    const validatedData = validateIntegrationData(type, config.data);
    // Save the integration to your data store, e.g., database
    // Example: this.prismaService.integration.create(...)
    return validatedData;
  }

  public async connectToIntegration(type: IntegrationType, config: object) {
    const service = this.integrationServices.get(type);
    if (service) {
      return await service.connect(config);
    } else {
      throw new Error(`Integration type ${type} is not supported`);
    }
  }

  public async disconnectFromIntegration(type: IntegrationType) {
    const service = this.integrationServices.get(type);
    if (service) {
      return await service.disconnect();
    } else {
      throw new Error(`Integration type ${type} is not supported`);
    }
  }

  public async performIntegrationAction(
    type: IntegrationType,
    action: string,
    params: object,
  ) {
    const service = this.integrationServices.get(type);
    if (service) {
      return await service.performAction(action, params);
    } else {
      throw new Error(`Integration type ${type} is not supported`);
    }
  }
}
