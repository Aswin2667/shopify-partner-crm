export interface IntegrationService<T> {
    connect(config: T): Promise<void>;
    disconnect(): Promise<void>;
    performAction(action: string, params: T): Promise<any>;
  }
  