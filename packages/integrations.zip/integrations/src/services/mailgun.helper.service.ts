import { IntegrationService } from '../integration.service';

export class MailgunIntegrationService implements IntegrationService<object> {
  async connect(config: object): Promise<void> {
    // Implement Mailgun connection logic
  }

  async disconnect(): Promise<void> {
    // Implement Mailgun disconnection logic
  }

  async performAction(action: string, params: object): Promise<any> {
    // Implement Mailgun action logic
  }
}
