import { IntegrationService } from '../integration.service';

export class ShopifyIntegrationService implements IntegrationService<object> {
  async connect(config: object): Promise<void> {
    // Implement Shopify connection logic
  }

  async disconnect(): Promise<void> {
    // Implement Shopify disconnection logic
  }

  async performAction(action: string, params: object): Promise<any> {
    // Implement Shopify action logic
  }
}
